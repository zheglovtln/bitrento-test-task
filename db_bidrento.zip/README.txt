Import bidrento.sql to mysql database.
Structure + data.